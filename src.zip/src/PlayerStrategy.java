/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author p4790084
 */
import acm.util.RandomGenerator;
import java.util.ArrayList;

public interface PlayerStrategy {


public boolean getDecision(ArrayList<Boolean> enemyDecision);
  

   

 
}
