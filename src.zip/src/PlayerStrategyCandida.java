
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author p4790084
 */
public class PlayerStrategyCandida implements PlayerStrategy{
    
     public boolean getDecision(ArrayList<Boolean> enemyDecision) {
        return true;
    }
}
